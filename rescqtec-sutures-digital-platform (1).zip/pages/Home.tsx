
import React from 'react';
import { NavLink } from 'react-router-dom';
import { PRODUCTS } from '../constants';
import ProductCard from '../components/ProductCard';

const Home: React.FC = () => {
  const featured = PRODUCTS.slice(0, 3);

  return (
    <div className="flex flex-col">
      {/* Hero Section */}
      <section className="relative bg-slate-900 overflow-hidden min-h-[85vh] flex items-center">
        <div className="absolute inset-0 z-0 opacity-20">
          <img 
            src="https://picsum.photos/1920/1080?medical" 
            alt="Medical Background" 
            className="w-full h-full object-cover filter grayscale"
          />
        </div>
        <div className="absolute inset-0 bg-gradient-to-r from-slate-900 via-slate-900 to-transparent z-1"></div>
        
        <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-20">
          <div className="max-w-2xl">
            <span className="inline-block bg-[#B8860B] text-white px-4 py-1 rounded-md text-xs font-bold uppercase tracking-[0.2em] mb-6 animate-fade-in">
              Namakkal, Tamil Nadu
            </span>
            <h1 className="text-5xl md:text-7xl font-bold text-white mb-6 leading-tight">
              Performance <span className="text-[#B8860B]">You Can Feel.</span><br />
              Healing <span className="text-blue-400">You Can Trust.</span>
            </h1>
            <p className="text-lg md:text-xl text-slate-300 mb-10 leading-relaxed max-w-lg">
              Advanced Wound Closure Solutions from India to the World. 
              CDSCO Licensed & ISO 13485:2016 Certified precision engineering.
            </p>
            <div className="flex flex-col sm:flex-row space-y-4 sm:space-y-0 sm:space-x-4">
              <NavLink 
                to="/products" 
                className="bg-[#B8860B] text-white px-10 py-4 rounded-full text-lg font-bold hover:bg-opacity-90 transition-all text-center"
              >
                Explore Products
              </NavLink>
              <NavLink 
                to="/quality" 
                className="border-2 border-slate-600 text-white px-10 py-4 rounded-full text-lg font-bold hover:bg-slate-800 transition-all text-center"
              >
                View Certifications
              </NavLink>
            </div>
          </div>
        </div>

        {/* Floating Badges */}
        <div className="absolute bottom-12 right-12 hidden lg:flex space-x-8">
          <div className="bg-white/5 backdrop-blur-md border border-white/10 p-4 rounded-xl flex items-center space-x-4">
             <div className="w-12 h-12 bg-purple-600/20 rounded-lg flex items-center justify-center text-purple-400 font-bold">MED</div>
             <div>
                <p className="text-white text-sm font-bold">Absorbable</p>
                <p className="text-slate-400 text-xs">Synthetic Synthetics</p>
             </div>
          </div>
          <div className="bg-white/5 backdrop-blur-md border border-white/10 p-4 rounded-xl flex items-center space-x-4">
             <div className="w-12 h-12 bg-blue-600/20 rounded-lg flex items-center justify-center text-blue-400 font-bold">NEO</div>
             <div>
                <p className="text-white text-sm font-bold">Non-Absorbable</p>
                <p className="text-slate-400 text-xs">Precision Polymers</p>
             </div>
          </div>
        </div>
      </section>

      {/* Featured Products */}
      <section className="py-24 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-20">
            <h2 className="text-sm font-bold text-[#B8860B] uppercase tracking-widest mb-4">Precision Engineering</h2>
            <p className="text-4xl font-bold text-slate-900 mb-6">Our Featured Brands</p>
            <p className="text-slate-500 max-w-2xl mx-auto">
              Engineered for strength, flexibility, and minimal tissue reaction. Trusted by surgeons globally for complex procedures.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {featured.map(product => (
              <ProductCard key={product.id} product={product} />
            ))}
          </div>

          <div className="text-center mt-16">
             <NavLink 
              to="/products" 
              className="inline-flex items-center text-[#B8860B] font-bold text-lg hover:underline"
            >
              View Entire Catalogue
              <svg className="w-5 h-5 ml-2" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M17 8l4 4m0 0l-4 4m4-4H3"/></svg>
            </NavLink>
          </div>
        </div>
      </section>

      {/* Value Prop Section */}
      <section className="py-24 bg-slate-50 border-y border-slate-100">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-12">
            <div className="flex flex-col items-center text-center">
              <div className="w-16 h-16 bg-blue-100 text-blue-600 rounded-2xl flex items-center justify-center mb-6">
                <svg className="w-8 h-8" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M9 12l2 2 4-4m5.618-4.016A11.955 11.955 0 0112 2.944a11.955 11.955 0 01-8.618 3.04A12.02 12.02 0 003 9c0 5.591 3.824 10.29 9 11.622 5.176-1.332 9-6.03 9-11.622 0-1.042-.133-2.052-.382-3.016z"/></svg>
              </div>
              <h3 className="text-xl font-bold mb-4">Quality Assured</h3>
              <p className="text-slate-500 text-sm">Every suture undergoes rigorous testing to meet ISO 13485:2016 standards and CDSCO regulations.</p>
            </div>
            <div className="flex flex-col items-center text-center">
              <div className="w-16 h-16 bg-purple-100 text-purple-600 rounded-2xl flex items-center justify-center mb-6">
                <svg className="w-8 h-8" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M19.428 15.428a2 2 0 00-1.022-.547l-2.387-.477a2 2 0 00-1.96 1.414l-.727 2.903a2 2 0 01-1.33 1.33l-2.903.727a2 2 0 00-1.414 1.96l.477 2.387a2 2 0 00.547 1.022l1.585 1.585a2 2 0 010 2.828l-1.585 1.585a2 2 0 00-.547 1.022l-.477 2.387a2 2 0 001.96 1.414l2.903-.727a2 2 0 011.33 1.33l.727 2.903a2 2 0 001.96 1.414l2.387-.477a2 2 0 001.022-.547l1.585-1.585a2 2 0 012.828 0l1.585 1.585z"/></svg>
              </div>
              <h3 className="text-xl font-bold mb-4">Advanced Tech</h3>
              <p className="text-slate-500 text-sm">From Triclosan-coated antibacterial threads to knotless PDS BARB technology, we innovate for better outcomes.</p>
            </div>
            <div className="flex flex-col items-center text-center">
              <div className="w-16 h-16 bg-amber-100 text-amber-600 rounded-2xl flex items-center justify-center mb-6">
                <svg className="w-8 h-8" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M21 12a9 9 0 01-9 9m9-9a9 9 0 00-9-9m9 9H3m9 9a9 9 0 01-9-9m9 9c1.657 0 3-4.03 3-9s-1.343-9-3-9m0 18c-1.657 0-3-4.03-3-9s1.343-9 3-9m-9 9a9 9 0 019-9"/></svg>
              </div>
              <h3 className="text-xl font-bold mb-4">Global Reach</h3>
              <p className="text-slate-500 text-sm">Exporting precision-grade sutures from our state-of-the-art facility in Namakkal to surgeons worldwide.</p>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
};

export default Home;
