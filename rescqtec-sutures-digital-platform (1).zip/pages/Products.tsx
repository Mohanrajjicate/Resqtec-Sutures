
import React, { useState, useMemo } from 'react';
import { useSearchParams } from 'react-router-dom';
import { PRODUCTS } from '../constants';
import { SutureCategory } from '../types';
import ProductCard from '../components/ProductCard';

const Products: React.FC = () => {
  const [searchParams, setSearchParams] = useSearchParams();
  const initialCat = searchParams.get('cat') === 'non-absorbable' ? 'Non-Absorbable' : 'Absorbable';
  
  const [activeCategory, setActiveCategory] = useState<SutureCategory>(initialCat as SutureCategory);
  const [searchQuery, setSearchQuery] = useState('');

  const filteredProducts = useMemo(() => {
    return PRODUCTS.filter(p => {
      const matchesCategory = p.category === activeCategory;
      const matchesSearch = 
        p.name.toLowerCase().includes(searchQuery.toLowerCase()) || 
        p.brand.toLowerCase().includes(searchQuery.toLowerCase()) ||
        p.specs.some(s => s.code.toLowerCase().includes(searchQuery.toLowerCase()));
      return matchesCategory && matchesSearch;
    });
  }, [activeCategory, searchQuery]);

  const handleCategoryChange = (cat: SutureCategory) => {
    setActiveCategory(cat);
    setSearchParams({ cat: cat.toLowerCase().replace(' ', '-') });
  };

  return (
    <div className="bg-white min-h-screen">
      {/* Product Header */}
      <section className="bg-slate-900 py-16 text-center">
        <div className="max-w-7xl mx-auto px-4">
          <h1 className="text-4xl font-bold text-white mb-4">Surgical Suture Catalogue</h1>
          <p className="text-slate-400 max-w-2xl mx-auto">
            Browse our comprehensive range of high-performance absorbable and non-absorbable wound closure solutions.
          </p>
        </div>
      </section>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        {/* Controls */}
        <div className="flex flex-col md:flex-row justify-between items-center mb-12 space-y-6 md:space-y-0">
          <div className="inline-flex p-1 bg-gray-100 rounded-xl">
            <button 
              onClick={() => handleCategoryChange('Absorbable')}
              className={`px-8 py-3 rounded-lg text-sm font-bold transition-all ${activeCategory === 'Absorbable' ? 'bg-white text-slate-900 shadow-md' : 'text-slate-500 hover:text-slate-700'}`}
            >
              Absorbable
            </button>
            <button 
              onClick={() => handleCategoryChange('Non-Absorbable')}
              className={`px-8 py-3 rounded-lg text-sm font-bold transition-all ${activeCategory === 'Non-Absorbable' ? 'bg-white text-slate-900 shadow-md' : 'text-slate-500 hover:text-slate-700'}`}
            >
              Non-Absorbable
            </button>
          </div>

          <div className="relative w-full md:w-96">
            <input 
              type="text" 
              placeholder="Search by name or code (e.g. RSA 2478)"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full pl-12 pr-4 py-3 bg-gray-50 border border-gray-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-[#B8860B]/50 transition-all"
            />
            <svg className="absolute left-4 top-3.5 w-5 h-5 text-gray-400" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z"/></svg>
          </div>
        </div>

        {/* Results */}
        {filteredProducts.length > 0 ? (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {filteredProducts.map(product => (
              <ProductCard key={product.id} product={product} />
            ))}
          </div>
        ) : (
          <div className="py-24 text-center">
            <div className="inline-flex items-center justify-center w-16 h-16 bg-gray-100 text-gray-400 rounded-full mb-6">
               <svg className="w-8 h-8" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M9.172 9.172a4 4 0 015.656 0M9 10h.01M15 10h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z"/></svg>
            </div>
            <h3 className="text-xl font-bold text-slate-900 mb-2">No products found</h3>
            <p className="text-slate-500">Try adjusting your search or filters to find what you're looking for.</p>
          </div>
        )}
      </div>

      {/* Technical Note */}
      <section className="bg-slate-50 py-16 mt-24 border-t border-slate-100">
        <div className="max-w-4xl mx-auto px-4 text-center">
           <h4 className="text-lg font-bold text-slate-900 mb-4">Technical Specifications Note</h4>
           <p className="text-sm text-slate-500 leading-relaxed">
             The product codes listed above represent only a selection of our full inventory. We offer a wide variety of needle profiles (Round Bodied, Cutting, Reverse Cutting, Taper Point, Taper Cut) and suture lengths tailored to specific surgical requirements. For the complete range, please download our official catalogue.
           </p>
           <button className="mt-8 bg-slate-900 text-white px-8 py-3 rounded-lg text-sm font-bold hover:bg-slate-800 transition-all">
             Download Full Catalogue (PDF)
           </button>
        </div>
      </section>
    </div>
  );
};

export default Products;
