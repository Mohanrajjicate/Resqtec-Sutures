
import React, { useState } from 'react';

const Contact: React.FC = () => {
  const [formState, setFormState] = useState({
    name: '',
    hospital: '',
    interest: 'General',
    message: ''
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    alert('Thank you for your interest. Our sales team will contact you shortly.');
    setFormState({ name: '', hospital: '', interest: 'General', message: '' });
  };

  return (
    <div className="bg-slate-50 min-h-screen py-24">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-16">
          
          {/* Contact Info */}
          <div>
            <span className="text-[#B8860B] font-bold uppercase tracking-widest text-sm mb-4 block">Get In Touch</span>
            <h1 className="text-4xl font-bold text-slate-900 mb-8 leading-tight">Partner with India's Premier Suture Manufacturer</h1>
            <p className="text-slate-500 text-lg mb-12">
              Whether you are a hospital procurement officer or an international distributor, our team is ready to support your surgical requirements with precision-grade solutions.
            </p>

            <div className="space-y-8">
              <div className="flex items-start space-x-6">
                 <div className="w-14 h-14 bg-white rounded-2xl shadow-sm flex items-center justify-center text-[#B8860B] flex-shrink-0">
                    <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M17.657 16.657L13.414 20.9a1.998 1.998 0 01-2.827 0l-4.244-4.243a8 8 0 1111.314 0z"/><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M15 11a3 3 0 11-6 0 3 3 0 016 0z"/></svg>
                 </div>
                 <div>
                    <h4 className="text-lg font-bold text-slate-900 mb-1">Our Location</h4>
                    <p className="text-slate-500 text-sm">No: 358A-2, Salem Main Road, Kumarapalayam,<br />Namakkal, Tamil Nadu - 638183.</p>
                 </div>
              </div>

              <div className="flex items-start space-x-6">
                 <div className="w-14 h-14 bg-white rounded-2xl shadow-sm flex items-center justify-center text-[#B8860B] flex-shrink-0">
                    <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M3 5a2 2 0 012-2h3.28a1 1 0 01.948.684l1.498 4.493a1 1 0 01-.502 1.21l-2.257 1.13a11.042 11.042 0 005.516 5.516l1.13-2.257a1 1 0 011.21-.502l4.493 1.498a1 1 0 01.684.949V19a2 2 0 01-2 2h-1C9.716 21 3 14.284 3 6V5z"/></svg>
                 </div>
                 <div>
                    <h4 className="text-lg font-bold text-slate-900 mb-1">Phone Support</h4>
                    <p className="text-slate-500 text-sm">+91 93539 53097<br />Mon - Sat, 9:00 AM - 6:00 PM IST</p>
                 </div>
              </div>

              <div className="flex items-start space-x-6">
                 <div className="w-14 h-14 bg-white rounded-2xl shadow-sm flex items-center justify-center text-[#B8860B] flex-shrink-0">
                    <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M3 8l7.89 5.26a2 2 0 002.22 0L21 8M5 19h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v10a2 2 0 002 2z"/></svg>
                 </div>
                 <div>
                    <h4 className="text-lg font-bold text-slate-900 mb-1">Email Inquiry</h4>
                    <p className="text-slate-500 text-sm">sales@rescqtec.com<br />General Inquiries: info@rescqtec.com</p>
                 </div>
              </div>
            </div>

            {/* Embed Placeholder */}
            <div className="mt-12 h-64 bg-gray-200 rounded-3xl relative overflow-hidden flex items-center justify-center text-slate-400 text-sm font-semibold">
               <img src="https://picsum.photos/800/400?map" className="absolute inset-0 w-full h-full object-cover opacity-50" alt="Location Map" />
               <div className="relative z-10 bg-white/90 px-6 py-3 rounded-full shadow-lg text-slate-800">
                 Pin: Kumarapalayam, Tamil Nadu
               </div>
            </div>
          </div>

          {/* Contact Form */}
          <div className="bg-white rounded-3xl shadow-xl p-8 md:p-12 border border-slate-100">
             <h3 className="text-2xl font-bold text-slate-900 mb-6">Send a Message</h3>
             <form onSubmit={handleSubmit} className="space-y-6">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                   <div>
                      <label className="block text-xs font-bold text-slate-400 uppercase mb-2">Your Name</label>
                      <input 
                        required
                        type="text" 
                        value={formState.name}
                        onChange={(e) => setFormState({...formState, name: e.target.value})}
                        className="w-full px-4 py-3 rounded-xl border border-gray-100 bg-gray-50 focus:outline-none focus:ring-2 focus:ring-[#B8860B]/50"
                        placeholder="John Doe"
                      />
                   </div>
                   <div>
                      <label className="block text-xs font-bold text-slate-400 uppercase mb-2">Hospital/Company</label>
                      <input 
                        required
                        type="text" 
                        value={formState.hospital}
                        onChange={(e) => setFormState({...formState, hospital: e.target.value})}
                        className="w-full px-4 py-3 rounded-xl border border-gray-100 bg-gray-50 focus:outline-none focus:ring-2 focus:ring-[#B8860B]/50"
                        placeholder="Apollo Hospitals"
                      />
                   </div>
                </div>
                <div>
                   <label className="block text-xs font-bold text-slate-400 uppercase mb-2">Product Interest</label>
                   <select 
                      value={formState.interest}
                      onChange={(e) => setFormState({...formState, interest: e.target.value})}
                      className="w-full px-4 py-3 rounded-xl border border-gray-100 bg-gray-50 focus:outline-none focus:ring-2 focus:ring-[#B8860B]/50"
                   >
                      <option>MEDCryl Absorbable</option>
                      <option>NEOLene Cardiovascular</option>
                      <option>Knotless BARB Technology</option>
                      <option>Bulk Distribution</option>
                      <option>General Inquiry</option>
                   </select>
                </div>
                <div>
                   <label className="block text-xs font-bold text-slate-400 uppercase mb-2">Message</label>
                   <textarea 
                      required
                      rows={4}
                      value={formState.message}
                      onChange={(e) => setFormState({...formState, message: e.target.value})}
                      className="w-full px-4 py-3 rounded-xl border border-gray-100 bg-gray-50 focus:outline-none focus:ring-2 focus:ring-[#B8860B]/50"
                      placeholder="How can we help you today?"
                   ></textarea>
                </div>
                <button 
                   type="submit"
                   className="w-full bg-slate-900 text-white py-4 rounded-xl font-bold text-lg hover:bg-slate-800 transition-all shadow-lg"
                >
                   Send Request
                </button>
                <p className="text-[10px] text-center text-slate-400 uppercase tracking-widest mt-4">
                  Response within 24 business hours
                </p>
             </form>
          </div>

        </div>
      </div>
    </div>
  );
};

export default Contact;
