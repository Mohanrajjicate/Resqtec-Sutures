
import React from 'react';

const Quality: React.FC = () => {
  return (
    <div className="bg-white min-h-screen">
      {/* Page Hero */}
      <section className="bg-[#B8860B] py-24 text-center relative overflow-hidden">
        <div className="absolute inset-0 opacity-10">
          <svg className="w-full h-full" viewBox="0 0 100 100" preserveAspectRatio="none">
             <path d="M0 0 L100 0 L100 100 L0 100 Z" fill="url(#grid)"></path>
             <defs>
               <pattern id="grid" width="10" height="10" patternUnits="userSpaceOnUse">
                 <path d="M 10 0 L 0 0 0 10" fill="none" stroke="white" strokeWidth="0.5"/>
               </pattern>
             </defs>
          </svg>
        </div>
        <div className="relative z-10 max-w-7xl mx-auto px-4">
          <h1 className="text-4xl md:text-5xl font-bold text-white mb-6">Uncompromising Quality</h1>
          <p className="text-white/80 max-w-2xl mx-auto text-lg">
            Manufacturing excellence backed by global standards and local regulatory compliance.
          </p>
        </div>
      </section>

      {/* Badges Section */}
      <section className="py-20 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-12 items-center">
           <div className="space-y-8">
              <div className="border-l-4 border-[#B8860B] pl-6">
                <h2 className="text-3xl font-bold text-slate-900 mb-4">Certified for Excellence</h2>
                <p className="text-slate-500 leading-relaxed">
                  Rescqtec Sutures Private Limited is a dedicated manufacturer of high-quality surgical sutures. Our state-of-the-art facility in Kumarapalayam is built to meet international cleanroom standards.
                </p>
              </div>
              <ul className="space-y-6">
                <li className="flex items-start">
                   <div className="w-12 h-12 bg-green-100 text-green-600 rounded-xl flex items-center justify-center mr-4 flex-shrink-0">
                     <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z"/></svg>
                   </div>
                   <div>
                      <h4 className="font-bold text-slate-900">ISO 13485:2016 Certified</h4>
                      <p className="text-sm text-slate-500">Adhering to the most rigorous quality management systems for medical device manufacturing.</p>
                   </div>
                </li>
                <li className="flex items-start">
                   <div className="w-12 h-12 bg-blue-100 text-blue-600 rounded-xl flex items-center justify-center mr-4 flex-shrink-0">
                     <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M19 21V5a2 2 0 00-2-2H7a2 2 0 00-2 2v16m14 0h2m-2 0h-5m-9 0H3m2 0h5M9 7h1m-1 4h1m4-4h1m-1 4h1m-5 10v-5a1 1 0 011-1h2a1 1 0 011 1v5m-4 0h4"/></svg>
                   </div>
                   <div>
                      <h4 className="font-bold text-slate-900">CDSCO Licensed</h4>
                      <p className="text-sm text-slate-500">Fully licensed by the Central Drugs Standard Control Organisation for Class C medical devices.</p>
                   </div>
                </li>
              </ul>
           </div>
           <div className="bg-slate-50 rounded-3xl p-8 border border-slate-100">
              <div className="flex justify-center mb-8 space-x-8">
                 <div className="bg-white p-6 rounded-2xl shadow-sm border border-gray-100 text-center w-40">
                    <div className="text-[#B8860B] font-bold text-lg mb-2">ISO</div>
                    <div className="text-slate-400 text-[10px] uppercase font-bold tracking-widest">13485:2016</div>
                 </div>
                 <div className="bg-white p-6 rounded-2xl shadow-sm border border-gray-100 text-center w-40">
                    <div className="text-blue-600 font-bold text-lg mb-2">CDSCO</div>
                    <div className="text-slate-400 text-[10px] uppercase font-bold tracking-widest">Licensed</div>
                 </div>
              </div>
              <img 
                src="https://picsum.photos/600/400?manufacturing" 
                alt="Manufacturing Plant" 
                className="rounded-2xl shadow-xl"
              />
           </div>
        </div>
      </section>

      {/* Sterilization Section */}
      <section className="bg-slate-900 py-24 text-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-[#B8860B] font-bold uppercase tracking-widest text-sm mb-4">Sterilization Technology</h2>
            <p className="text-3xl font-bold">Safe, Sterile, Ready for Surgery</p>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-12">
            <div className="bg-white/5 p-8 rounded-2xl border border-white/10">
              <h3 className="text-xl font-bold mb-4 text-[#B8860B]">ETO Sterilization</h3>
              <p className="text-slate-400 text-sm leading-relaxed mb-6">
                Ethylene Oxide (ETO) sterilization is our primary method for temperature-sensitive sutures. This process ensures 100% sterility without compromising the structural integrity of the polymer chains.
              </p>
              <ul className="space-y-2 text-xs text-slate-500">
                <li className="flex items-center"><span className="w-1.5 h-1.5 bg-[#B8860B] rounded-full mr-3"></span>Validated processes for every batch</li>
                <li className="flex items-center"><span className="w-1.5 h-1.5 bg-[#B8860B] rounded-full mr-3"></span>Minimal residual gas levels</li>
                <li className="flex items-center"><span className="w-1.5 h-1.5 bg-[#B8860B] rounded-full mr-3"></span>Ideal for PGLA and Nylon sutures</li>
              </ul>
            </div>
            <div className="bg-white/5 p-8 rounded-2xl border border-white/10">
              <h3 className="text-xl font-bold mb-4 text-blue-400">Gamma Sterilization</h3>
              <p className="text-slate-400 text-sm leading-relaxed mb-6">
                For non-sensitive product lines, we utilize Gamma Irradiation to achieve a high Sterility Assurance Level (SAL). This method provides deep penetration and instant results for high-volume manufacturing.
              </p>
              <ul className="space-y-2 text-xs text-slate-500">
                <li className="flex items-center"><span className="w-1.5 h-1.5 bg-blue-400 rounded-full mr-3"></span>High penetration power</li>
                <li className="flex items-center"><span className="w-1.5 h-1.5 bg-blue-400 rounded-full mr-3"></span>Instant sterility verification</li>
                <li className="flex items-center"><span className="w-1.5 h-1.5 bg-blue-400 rounded-full mr-3"></span>Sustainable and chemical-free</li>
              </ul>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
};

export default Quality;
