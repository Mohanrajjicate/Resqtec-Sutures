
import React from 'react';
import { Product } from '../types';

interface ProductCardProps {
  product: Product;
}

const ProductCard: React.FC<ProductCardProps> = ({ product }) => {
  const isAntibacterial = product.brand === 'MEDCryl' && product.name.includes('-AB');
  
  // Mapping themeColor to specific Tailwind classes for border and bg accents
  const colorMap: Record<string, string> = {
    'indigo-500': 'bg-indigo-500 border-indigo-500',
    'red-600': 'bg-red-600 border-red-600',
    'purple-800': 'bg-purple-800 border-purple-800',
    'violet-600': 'bg-violet-600 border-violet-600',
    'orange-400': 'bg-orange-400 border-orange-400',
    'slate-500': 'bg-slate-500 border-slate-500',
    'zinc-700': 'bg-zinc-700 border-zinc-700',
    'amber-700': 'bg-amber-700 border-amber-700',
    'yellow-500': 'bg-yellow-500 border-yellow-500',
    'emerald-600': 'bg-emerald-600 border-emerald-600',
    'blue-700': 'bg-blue-700 border-blue-700',
    'cyan-600': 'bg-cyan-600 border-cyan-600',
    'orange-800': 'bg-orange-800 border-orange-800'
  };

  const textMap: Record<string, string> = {
    'indigo-500': 'text-indigo-500',
    'red-600': 'text-red-600',
    'purple-800': 'text-purple-800',
    'violet-600': 'text-violet-600',
    'orange-400': 'text-orange-400',
    'slate-500': 'text-slate-500',
    'zinc-700': 'text-zinc-700',
    'amber-700': 'text-amber-700',
    'yellow-500': 'text-yellow-500',
    'emerald-600': 'text-emerald-600',
    'blue-700': 'text-blue-700',
    'cyan-600': 'text-cyan-600',
    'orange-800': 'text-orange-800'
  };

  return (
    <div className={`bg-white rounded-2xl shadow-lg border-t-8 ${colorMap[product.themeColor].split(' ')[1]} overflow-hidden hover:shadow-2xl transition-all duration-300 group flex flex-col h-full`}>
      {/* Product Box Image Display */}
      <div className="bg-slate-50 h-52 flex items-center justify-center p-6 relative group-hover:bg-slate-100 transition-colors">
        <div className="absolute top-3 left-3 flex gap-2">
           <span className={`${colorMap[product.themeColor].split(' ')[0]} text-white text-[10px] font-bold px-2 py-0.5 rounded shadow-sm`}>
             {product.modality}
           </span>
           <span className="bg-white text-slate-800 text-[10px] font-bold px-2 py-0.5 rounded shadow-sm border border-slate-200">
             {product.category}
           </span>
        </div>
        <img 
          src={product.imageUrl} 
          alt={`${product.name} Packaging`}
          className="max-h-full max-w-full object-contain drop-shadow-xl transform group-hover:scale-105 transition-transform duration-500"
          onError={(e) => {
            // Fallback for missing local assets
            (e.target as HTMLImageElement).src = `https://placehold.co/400x300/${product.themeColor.split('-')[0]}/white?text=${product.name}`;
          }}
        />
      </div>

      <div className="p-6 flex flex-col flex-grow">
        <div className="flex justify-between items-start mb-2">
          <div>
            <h3 className="text-2xl font-bold text-slate-900 leading-tight">
              {product.name}
            </h3>
            <p className="text-[11px] font-bold text-slate-400 uppercase tracking-widest mt-0.5">{product.brand} Range</p>
          </div>
          {isAntibacterial && (
            <span className="bg-red-50 text-red-600 px-3 py-1 rounded-full text-[10px] font-bold uppercase border border-red-100 animate-pulse">
              Antibacterial
            </span>
          )}
        </div>

        <p className="text-sm text-slate-600 italic mb-4">{product.type}</p>

        <div className="mb-4 space-y-3">
          <p className="text-sm text-slate-600 leading-relaxed">{product.description}</p>
          
          <div className="flex flex-wrap gap-2 text-[10px] font-bold uppercase">
             <span className="bg-gray-100 px-2 py-1 rounded">Color: {product.color}</span>
             {product.absorptionTime && <span className="bg-gray-100 px-2 py-1 rounded">Absorption: {product.absorptionTime}</span>}
          </div>
        </div>

        <div className="mb-6">
          <h4 className="text-[10px] font-bold text-slate-900 uppercase mb-2 tracking-widest">Key Performance Indicators</h4>
          <ul className="space-y-2">
            {product.usp.map((point, idx) => (
              <li key={idx} className="flex items-start text-[13px] text-slate-700">
                <svg className={`w-4 h-4 mr-2 ${textMap[product.themeColor]} flex-shrink-0 mt-0.5`} fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2.5" d="M5 13l4 4L19 7"/>
                </svg>
                {point}
              </li>
            ))}
          </ul>
        </div>

        {product.tensileRetention && (
          <div className="mb-6 p-3 rounded-xl bg-slate-50 border border-slate-100">
             <h5 className="text-[10px] font-bold text-slate-900 uppercase mb-1 tracking-wider">Tensile Retention Profile</h5>
             <p className="text-xs text-slate-600">{product.tensileRetention}</p>
          </div>
        )}

        <div className="mt-auto border-t border-slate-100 pt-6">
           <h4 className="text-[10px] font-bold text-slate-900 mb-2 uppercase tracking-widest">Available Catalog Codes</h4>
           <div className="overflow-x-auto">
             <table className="w-full text-[11px]">
               <thead className="bg-slate-50 text-slate-500 rounded text-left">
                 <tr>
                   <th className="px-2 py-1.5 font-bold">Code</th>
                   <th className="px-2 py-1.5 font-bold">USP</th>
                   <th className="px-2 py-1.5 font-bold">Needle Profile</th>
                 </tr>
               </thead>
               <tbody className="divide-y divide-slate-50">
                 {product.specs.map((spec) => (
                   <tr key={spec.code}>
                     <td className="px-2 py-2 font-bold text-slate-900">{spec.code}</td>
                     <td className="px-2 py-2 text-slate-600">{spec.size}</td>
                     <td className="px-2 py-2 text-slate-600 truncate max-w-[120px]">{spec.needleType}</td>
                   </tr>
                 ))}
               </tbody>
             </table>
           </div>
        </div>
      </div>
      
      <div className="bg-slate-50 px-6 py-4 text-center border-t border-slate-100 group-hover:bg-slate-100 transition-colors">
        <button className={`${textMap[product.themeColor]} font-bold text-xs uppercase tracking-widest hover:underline flex items-center justify-center w-full`}>
          View Detailed Specifications
          <svg className="w-3.5 h-3.5 ml-2" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2.5" d="M17 8l4 4m0 0l-4 4m4-4H3"/></svg>
        </button>
      </div>
    </div>
  );
};

export default ProductCard;
