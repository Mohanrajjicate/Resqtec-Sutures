
import React, { useState } from 'react';
import { NavLink } from 'react-router-dom';
// Removed COLORS from import as it is not exported from constants.tsx
import { NAV_ITEMS } from '../constants';

const Header: React.FC = () => {
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);

  return (
    <header className="bg-white shadow-sm sticky top-0 z-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-center h-20">
          {/* Logo Section */}
          <div className="flex-shrink-0 flex items-center">
            <NavLink to="/" className="flex items-center space-x-2">
              <div className="w-10 h-10 bg-[#B8860B] rounded-full flex items-center justify-center text-white font-bold text-xl">R</div>
              <div>
                <span className="text-xl font-bold text-slate-900 block leading-none">RESCQTEC</span>
                <span className="text-[10px] tracking-widest text-[#B8860B] uppercase font-semibold">Sutures Pvt Ltd</span>
              </div>
            </NavLink>
          </div>

          {/* Desktop Nav */}
          <nav className="hidden md:flex space-x-8">
            {NAV_ITEMS.map((item) => (
              <div key={item.label} className="relative group">
                <NavLink
                  to={item.path}
                  className={({ isActive }) =>
                    `text-sm font-semibold transition-colors duration-200 ${
                      isActive ? 'text-[#B8860B]' : 'text-slate-600 hover:text-[#B8860B]'
                    }`
                  }
                >
                  {item.label}
                </NavLink>
                {item.dropdown && (
                  <div className="absolute left-0 mt-2 w-48 bg-white border border-gray-100 shadow-xl rounded-md py-2 hidden group-hover:block transition-all animate-in fade-in slide-in-from-top-2">
                    {item.dropdown.map((sub) => (
                      <NavLink
                        key={sub.label}
                        to={sub.path}
                        className="block px-4 py-2 text-xs font-semibold text-slate-600 hover:bg-gray-50 hover:text-[#B8860B]"
                      >
                        {sub.label}
                      </NavLink>
                    ))}
                  </div>
                )}
              </div>
            ))}
          </nav>

          {/* Search/Utility */}
          <div className="hidden md:flex items-center space-x-4">
            <NavLink 
              to="/products" 
              className="bg-[#B8860B] text-white px-5 py-2 rounded-full text-sm font-semibold hover:bg-opacity-90 transition-all flex items-center"
            >
              <svg className="w-4 h-4 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z"/></svg>
              Search by Code
            </NavLink>
          </div>

          {/* Mobile Menu Button */}
          <div className="md:hidden flex items-center">
            <button 
              onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
              className="text-slate-600 hover:text-slate-900 focus:outline-none"
            >
              <svg className="w-8 h-8" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d={isMobileMenuOpen ? "M6 18L18 6M6 6l12 12" : "M4 6h16M4 12h16M4 18h16"} />
              </svg>
            </button>
          </div>
        </div>
      </div>

      {/* Mobile Menu */}
      {isMobileMenuOpen && (
        <div className="md:hidden bg-white border-t border-gray-100 py-4 px-4 space-y-2">
          {NAV_ITEMS.map((item) => (
            <div key={item.label}>
              <NavLink
                to={item.path}
                onClick={() => setIsMobileMenuOpen(false)}
                className="block py-2 text-base font-semibold text-slate-700 hover:text-[#B8860B]"
              >
                {item.label}
              </NavLink>
              {item.dropdown && (
                <div className="pl-4 space-y-1">
                  {item.dropdown.map((sub) => (
                    <NavLink
                      key={sub.label}
                      to={sub.path}
                      onClick={() => setIsMobileMenuOpen(false)}
                      className="block py-1 text-sm text-slate-500"
                    >
                      {sub.label}
                    </NavLink>
                  ))}
                </div>
              )}
            </div>
          ))}
          <div className="pt-4">
             <NavLink 
              to="/products" 
              onClick={() => setIsMobileMenuOpen(false)}
              className="block bg-[#B8860B] text-white text-center px-5 py-3 rounded-md text-sm font-semibold"
            >
              Search Product Catalogue
            </NavLink>
          </div>
        </div>
      )}
    </header>
  );
};

export default Header;
